<div class="elementor-element elementor-element-1dbaee9 elementor-widget elementor-widget-bacola-text-banner"
    data-id="1dbaee9" data-element_type="widget" data-widget_type="bacola-text-banner.default">
    <div class="elementor-widget-container">
        <div class="site-module module-purchase-banner">
            <div class="module-body"><a href="https://klbtheme.com/bacola/shop/"><span class="purchase-text">Super discount
                        for your <strong>first
                            purchase.</strong></span><span class="purchase-code">{{ $config->counpon->code }}</span><span
                        class="purchase-description">Use discount code in
                        checkout!</span></a></div>
        </div>
    </div>
</div>
