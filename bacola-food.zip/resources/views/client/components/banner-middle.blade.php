<div class="elementor-element elementor-element-2ce0c75 elementor-widget elementor-widget-bacola-banner-box2"
    data-id="2ce0c75" data-element_type="widget" data-widget_type="bacola-banner-box2.default">
    <div class="elementor-widget-container">
        <div class="site-module module-banner wide">
            <div class="module-body">
                <div class="banner-wrapper">
                    <div class="banner-content">
                        <h4 class="sub-text color-info-dark">Always Taking Care</h4>
                        <h3 class="entry-title mini color-text-lighter">In store or
                            online your health &amp; safety is our top priority.
                        </h3>
                    </div>
                    <div class="banner-thumbnail"><img decoding="async"
                            src="https://klbtheme.com/bacola/wp-content/plugins/bacola-core/elementor/images/banner-box2.jpg"
                            alt="banner"></div><a href="https://klbtheme.com/bacola/shop/?filter_cat=58"
                        class="overlay-link"></a>
                </div>
            </div>
        </div>
    </div>
</div>
