@include('layouts.client.includes.header')

@yield('content')

@include('layouts.client.includes.footer')