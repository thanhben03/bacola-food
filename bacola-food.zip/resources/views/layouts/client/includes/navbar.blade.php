<nav class="site-menu primary-menu horizontal">
    <ul id="menu-menu-2" class="menu">
        <li class="dropdown  menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home current-menu-ancestor current-menu-parent menu-item-has-children">
            <a href="#">Home</a>
            <ul class="sub-menu">
                <li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-50 current_page_item">
                    <a href="#">Home 1</a>
                </li>
                <li class=" menu-item menu-item-type-post_type menu-item-object-page"><a href="#">Home 2</a></li>
                <li class=" menu-item menu-item-type-post_type menu-item-object-page"><a href="#">Home 3</a></li>
                <li class=" menu-item menu-item-type-post_type menu-item-object-page"><a href="#">Home 4</a></li>
                <li class=" menu-item menu-item-type-post_type menu-item-object-page"><a href="#">Home 5</a></li>
            </ul>
        </li>
        <li class="dropdown mega-menu menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children">
            <a href="#">Shop</a>
            <ul class="sub-menu">
                <li class="dropdown  menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children">
                    <a href="#">Shop Lists</a>
                    <ul class="sub-menu">
                        <li class=" menu-item menu-item-type-post_type menu-item-object-page"><a href="">Shop Default</a></li>
                        <li class=" menu-item menu-item-type-custom menu-item-object-custom"><a href="#">Shop Right
                                Sidebar</a></li>
                        <li class=" menu-item menu-item-type-custom menu-item-object-custom"><a href="#">Shop
                                Wide</a></li>
                        <li class=" menu-item menu-item-type-custom menu-item-object-custom"><a href="#">List Left
                                Sidebar</a></li>
                        <li class=" menu-item menu-item-type-custom menu-item-object-custom"><a href="#">Load More
                                Button</a></li>
                        <li class=" menu-item menu-item-type-custom menu-item-object-custom"><a href="#">Infinite
                                Scrolling</a></li>
                    </ul>
                </li>
                <li class="dropdown  menu-item menu-item-type-post_type menu-item-object-product menu-item-has-children">
                    <a href="https://klbtheme.com/bacola/product/all-natural-italian-style-chicken-meatballs/">Product
                        Detail</a>
                    <ul class="sub-menu">
                        <li class=" menu-item menu-item-type-post_type menu-item-object-product"><a href="#">Product
                                Default</a></li>
                        <li class=" menu-item menu-item-type-post_type menu-item-object-product"><a href="#">Product
                                Variable</a></li>
                        <li class=" menu-item menu-item-type-post_type menu-item-object-product"><a href="#">Product
                                Grouped</a></li>
                        <li class=" menu-item menu-item-type-post_type menu-item-object-product"><a href="#">Product
                                External</a></li>
                        <li class=" menu-item menu-item-type-post_type menu-item-object-product"><a href="#">Product
                                Downloadable</a></li>
                        <li class=" menu-item menu-item-type-post_type menu-item-object-product"><a href="#">Product
                                With Video</a></li>
                    </ul>
                </li>
                <li class="dropdown  menu-item menu-item-type-post_type menu-item-object-product menu-item-has-children">
                    <a href="https://klbtheme.com/bacola/product/all-natural-italian-style-chicken-meatballs/">Product
                        Types</a>
                    <ul class="sub-menu">
                        <li class=" menu-item menu-item-type-post_type menu-item-object-product"><a href="#">Single
                                Type 1</a></li>
                        <li class=" menu-item menu-item-type-custom menu-item-object-custom"><a href="#">Single
                                Type 2</a></li>
                        <li class=" menu-item menu-item-type-custom menu-item-object-custom"><a href="#">Single
                                Type 3</a></li>
                        <li class=" menu-item menu-item-type-custom menu-item-object-custom"><a href="#">Single
                                Type 4</a></li>
                        <li class=" menu-item menu-item-type-custom menu-item-object-custom"><a href="#">Thumbnails
                                Left</a></li>
                        <li class=" menu-item menu-item-type-custom menu-item-object-custom"><a href="#">Zoom
                                Image</a></li>
                    </ul>
                </li>
                <li class="dropdown  menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children">
                    <a href="#">Shop Pages</a>
                    <ul class="sub-menu">
                        <li class=" menu-item menu-item-type-post_type menu-item-object-page"><a href="#">Cart</a></li>
                        <li class=" menu-item menu-item-type-post_type menu-item-object-page"><a href="#">Checkout</a></li>
                        <li class=" menu-item menu-item-type-post_type menu-item-object-page"><a href="#">My account</a></li>
                        <li class=" menu-item menu-item-type-post_type menu-item-object-page"><a href="#">Wishlist</a></li>
                        <li class=" menu-item menu-item-type-post_type menu-item-object-page"><a href="#">Order Tracking</a>
                        </li>
                        <li class=" menu-item menu-item-type-custom menu-item-object-custom"><a href="#">Order
                                on WhatsApp</a></li>
                    </ul>
                </li>
                <li class="dropdown  menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children">
                    <a href="#">Shop Layouts</a>
                    <ul class="sub-menu">
                        <li class=" menu-item menu-item-type-custom menu-item-object-custom"><a href="#">Two Columns</a></li>
                        <li class=" menu-item menu-item-type-custom menu-item-object-custom"><a href="#">Three Columns</a></li>
                        <li class=" menu-item menu-item-type-custom menu-item-object-custom"><a href="#">Three
                                Columns Wide</a></li>
                        <li class=" menu-item menu-item-type-custom menu-item-object-custom"><a href="#">Four Columns</a></li>
                        <li class=" menu-item menu-item-type-custom menu-item-object-custom"><a href="#">Four
                                Columns Wide</a></li>
                        <li class=" menu-item menu-item-type-custom menu-item-object-custom"><a href="#">Five
                                Columns wide</a></li>
                    </ul>
                </li>
            </ul>
        </li>
        <li class=" menu-item menu-item-type-taxonomy menu-item-object-product_cat"><a href="#"><i class="klbth-icon-meat"></i> Meats &amp; Seafood</a></li>
        <li class=" menu-item menu-item-type-taxonomy menu-item-object-product_cat"><a href="#"><i class="klbth-icon-biscuit"></i> Bakery</a></li>
        <li class=" menu-item menu-item-type-taxonomy menu-item-object-product_cat"><a href="#"><i class="klbth-icon-cup"></i> Beverages</a></li>
        <li class=" menu-item menu-item-type-post_type menu-item-object-page"><a href="#">Blog</a></li>
        <li class=" menu-item menu-item-type-post_type menu-item-object-page"><a href="#">Contact</a></li>
    </ul>
</nav><!-- site-menu -->